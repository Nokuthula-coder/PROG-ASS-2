/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.runapplication;

/**
 *
 * @author Student
 */

public class RoadConstructionReport  extends RoadsConstructed {
    
    // Constructor
    public RoadConstructionReport (String city, int totalRoadsConstructed){
        super (city, totalRoadsConstructed);
        
    }
    
    // Method to print report
    public void printRoadsConstructedReport(){
        System.out.println("City:" + getCity());
        System.out.println("Total Roads Constructed:" + getTotalRoadsConstructed());
       
        
    }   
}
