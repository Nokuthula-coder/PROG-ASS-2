/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.runapplication;
import java.util.Scanner;

/**
 *
 * @author Student
 */
public class RunApplication {

    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        
        // Ask the user to input the name of the city
        System.out.print("Please Enter the  name of the city: ");
        String city = scanner.nextLine();
        
        // Ask the user to input the number of the roads constructed
        System.out.print("Please Enter the total number of the roads constructed: ");
        int totalRoads = scanner.nextInt();
        
        // Create RoadContsructionReport using user input
        RoadConstructionReport report = new RoadConstructionReport (city, totalRoads);
        
        //Print the report
        System.out.println("\n====== Road Construction Report =====");
        report.printRoadsConstructedReport();
        
        scanner.close();
        
        
        
        
        
    }
}
