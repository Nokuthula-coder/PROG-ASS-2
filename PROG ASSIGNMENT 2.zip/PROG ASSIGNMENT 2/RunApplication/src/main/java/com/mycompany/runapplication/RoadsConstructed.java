/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.runapplication;

/**
 *
 * @author Student
 */
public abstract class RoadsConstructed implements IRoadsConstructed {
    
    protected String city ;
    protected int totalRoadsConstructed;
    
    // constructor
    public RoadsConstructed(String city, int totalRoadsConstructed){
        this.city = city;
        this.totalRoadsConstructed = totalRoadsConstructed;
        
    }
    
    // Getter methods
    @Override
    public String getCity(){
        return city;        
    }
    
    @Override
      public int getTotalRoadsConstructed(){
        return totalRoadsConstructed;      
    }   
}
