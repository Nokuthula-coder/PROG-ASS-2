/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sectiona;
import java.util.ArrayList;
import java.util.Scanner;


/**
 *
 * @author Student
 */
public class Property {
   
    ArrayList<PropertyModel> properties = new ArrayList<>();
    Scanner scanner = new Scanner(System.in);
    
    // Enter Property
    public void EnterProperty(){
        
        System.out.print("Enter Property ID: ");
        String id = scanner.nextLine();
        
        System.out.print("Enter Property Address: ");
        String address = scanner.nextLine();
        
        double rentalAmount = PropertyAmountValidation();
        
        System.out.print("Enter Agent Name: ");
        String agent = scanner.nextLine();
        
        PropertyModel property = new PropertyModel(id, address, rentalAmount, agent);
        
        properties.add(property);
        
        System.out.println("\nProperty rental details successfully processed!");
    }
    
    // Validate Rental Amount
    public double PropertyAmountValidation(){
        
        double amount = 0;
        
        while (true){
            
            try {
                System.out.print("Enter Property Rental Amount: ");
                amount = Double.parseDouble(scanner.nextLine());
                
                if (amount >= 1500){
                    break;
                }
                else {
                    System.out.println("Invalid amount! Amount must be R1500 or more.");
                }
                
            } catch (NumberFormatException e){
                System.out.println("Invalid input! Numbers only.");
            }
        }
        return amount;
    }
    
    // Search Property
    public void SearchProperty(){
        
        System.out.print("Enter Property ID to search: ");
        String id = scanner.nextLine();
        
        boolean found = false;
        
        for (PropertyModel property : properties){
            
            if (property.PropertyId.equals(id)){
                
                System.out.println("\nPROPERTY FOUND");
                System.out.println("Property ID: " + property.PropertyId);
                System.out.println("Property Address: " + property.PropertyAddress);
                System.out.println("Rental Amount: R" + property.PropertyRentalAmount);
                System.out.println("Agent Name: " + property.AgentName);
                
                found = true;
                break;
            }
        }
        
        if (!found){
            System.out.println("Property not found!");
            
        }
    }
    
    // Update Property
    public void UpdateProperty(){
        
        System.out.print("Enter Property ID to update: ");
        String id = scanner.nextLine();
        
        boolean found = false;
        
        for (PropertyModel property : properties){
            
            if (property.PropertyId.equals(id)){
                
                System.out.print("Enter New Property Address: ");
                property.PropertyAddress = scanner.nextLine();
                
                property.PropertyRentalAmount = PropertyAmountValidation();
                
                System.out.print("Enter New Agent Name: ");
                property.AgentName = scanner.nextLine();
                
                System.out.println("Property updated successfully!");
                
                found = true;
                break;
            }
        }
       
        if (!found){
            System.out.println("Property not found!");
        }
    }
    
    // Delete Property
    public void DeleteProperty(){
        
        System.out.print("Enter Property ID to delete: ");
        String id = scanner.nextLine();
        
        boolean found = false;
        
        for (PropertyModel property : properties){
            
            if (property.PropertyId.equals(id)){
                
                System.out.print("Are you sure you want to delete? (yes/no): ");
                String confirm = scanner.nextLine();
                
                if (confirm.equalsIgnoreCase("yes")){
                    properties.remove(property);
                
                System.out.println("Property deleted successfully!");
                
             }
                found = true;
                break;
            }
        }
       
        if (!found){
            System.out.println("Property not found!");
        }
    }
       
// Property Report
    public void PropertyRentalReport(){
        
        if (properties.isEmpty()){
            
            System.out.println("No properties available.");
            return;
        }
        
        int count = 1;
                
                for (PropertyModel property : properties){
                    
                System.out.println("\nProperty " + count++);
                System.out.println("=================================");
                System.out.println("PROPERTY ID: " + property.PropertyId);
                System.out.println("PROPERTY ADDRESS: " + property.PropertyAddress);
                System.out.println("PROPERTY RENTAL AMOUNT: R" + property.PropertyRentalAmount);
                System.out.println("PROPERTY AGENT: " + property.AgentName);
             }
        }
    
    // Exit Application 
    public void ExitPropertyApplication(){
        
        System.out.println("Exiting application..");
        System.exit(0);
        
    }
}
    
    
    
            
    
                
    
           
                
        
        
        
    
