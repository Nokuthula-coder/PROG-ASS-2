/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sectiona;

/**
 *
 * @author Student
 */
public class PropertyModel {
    
    public String PropertyId;
    public String PropertyAddress;
    public double PropertyRentalAmount;
    public String AgentName;
    
    //Constructor
    public PropertyModel( String propertyId, String propertyAddress, double propertyRentalAmount, String agentName ){
        
        PropertyId = propertyId;
        PropertyAddress = propertyAddress;
        PropertyRentalAmount = propertyRentalAmount;
        AgentName = agentName;     
    }   
}
