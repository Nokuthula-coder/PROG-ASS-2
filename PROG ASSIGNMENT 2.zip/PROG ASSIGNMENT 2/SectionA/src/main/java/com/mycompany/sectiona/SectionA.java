/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sectiona;
import java.util.Scanner;

/**
 *
 * @author Student
 */
public class SectionA {

    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        Property property = new Property();
        
        System.out.println("PROPERTY RENTALS - 2026");
        System.out.println("************************************");
        System.out.println("Enter (1) to launch menu or any other key to exit: ");
        
        String launch = scanner.nextLine();
        
        if (!launch.equals("1")){
            System.out.println("Application Closed.");
            return;
        }
        
        int choice ;
        
        do {
            System.out.println("\nPlease select one of the following menu items:");
            System.out.println("(1) Enter new property");
            System.out.println("(2) Search property");
            System.out.println("(3) Update property");
            System.out.println("(4) Delete property");
            System.out.println("(5) Print property report");
            System.out.println("(6) Exit application");
            
            System.out.print("Choice: ");
            choice = Integer.parseInt(scanner.nextLine());
            
            switch (choice){
                
                case 1: 
                    property.EnterProperty();
                    break;
                    
                case 2:
                    property.SearchProperty();
                    break;
                    
                case 3:
                    property.UpdateProperty();
                    break;
                    
                case 4:
                    property.DeleteProperty();
                    break;
                    
                case 5:
                    property.PropertyRentalReport();
                    break;
                    
                case 6:
                    property.ExitPropertyApplication();
                    break;   
                    
                default:
                    System.out.println("Invalid option");
            }
        } while (choice != 6);
     }
}

            
            
            
        

